# Fullstack Sample Project

Simple Express backend + vanilla frontend.

## Run Backend
cd backend
npm install
npm start

## Run Frontend
cd frontend
npm install -g serve
serve .
